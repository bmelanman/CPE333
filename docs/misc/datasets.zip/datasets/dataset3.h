#ifndef __DATASET_H
#define __DATASET_H
#define ARRAY_SIZE 9


#define DIM_SIZE 3 


int input1_data[ARRAY_SIZE] = 
{
    0,   3,   2,   0,   3,   1,   0,   3,   2  
};

int input2_data[ARRAY_SIZE] = 
{
    1,   1,   0,   3,   1,   2,   0,   0,   0
};



#endif //__DATASET_H
